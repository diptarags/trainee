drop table MOBILEDATA;

create table mobileData(mob_id number(6) primary key, 
													mob_name varchar2(30),
													mob_brand varchar2(20),
													mob_price number(10));
													
insert into MOBILEDATA values(1001,'A','LG',20000);

insert into MOBILEDATA values(1002,'B','Apple',30000);

insert into MOBILEDATA values(1003,'C','Micromax',10000);

select * from MOBILEDATA;

create sequence mob_seq_id start with 1000;

select mob_seq_id.nextval from dual;

update MOBILEDATA set mob_name='Sony' where mob_id='1003';