package com.cg.hbms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.Users;


@Repository("hbmsDao")
public class HbmsDaoImpl implements IHbmsDao
{
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public int addHotel(Hotels hotel)
	{
		entityManager.persist(hotel);
		entityManager.flush();
		return hotel.getHotelId();
	}

	@Override
	public int addUser(Users user) 
	{
		entityManager.persist(user);
		entityManager.flush();
		return user.getUserId();
	}

	@Override
	public int addRoom(RoomDetails room) 
	{
		entityManager.persist(room);
		entityManager.flush();
		return room.getRoomId();
	}

	@Override
	public int addBooking(BookingDetails book) 
	{
		entityManager.persist(book);
		entityManager.flush();
		return book.getBookingId();
	}

	@Override
	public List<Hotels> showHotels() 
	{
		Query  query=entityManager.createQuery("FROM Hotels");  
		List<Hotels> dataList=	 query.getResultList();
		return dataList;
	}

	@Override
	public List<RoomDetails> showRooms() 
	{
		Query query = entityManager.createQuery("FROM RoomDetails");  
		List<RoomDetails> dataList=	 query.getResultList();
		return dataList;
	}

	@Override
	public List<Users> showUsers() 
	{
		Query query = entityManager.createQuery("FROM Users");  
		List<Users> dataList = query.getResultList();
		return dataList;
	}

	@Override
	public List<BookingDetails> showBookings() 
	{
		Query query = entityManager.createQuery("FROM BookingDetails");  
		List<BookingDetails> dataList = query.getResultList();
		return dataList;
	}

	@Override
	public List<Hotels> searchHotels(String city) {
		Query query=entityManager.createQuery("FROM Hotels WHERE city=:CITY");
		query.setParameter("CITY", city);
		List<Hotels> hotelSearch= query.getResultList();
		return hotelSearch;
		
	}

	@Override
	public List<RoomDetails> searchRooms(String roomType) {
		Query query = entityManager.createQuery("FROM RoomDetails WHERE roomType=:ROOM_TYPE");
		query.setParameter("ROOM_TYPE", roomType);
		List<RoomDetails> roomSearch= query.getResultList();
		return roomSearch;
	}

	@Override
	public void removeHotel(int hotelId) 
	{
		Query query = entityManager.createQuery("DELETE FROM Hotels WHERE hotelId=:HOTEL_ID");
		query.setParameter("HOTEL_ID",hotelId);
		query.executeUpdate();	
		
	}

	@Override
	public void removeRoom(int roomId) {
		
		Query query=entityManager.createQuery("DELETE FROM RoomDetails WHERE roomId=:ROOM_ID");
		query.setParameter("ROOM_ID",roomId);
		query.executeUpdate();	
	}

	@Override
	public List<Users> searchUsers(int userId) {
		
		Query query=entityManager.createQuery("FROM Users WHERE userId=:USER_ID");
		query.setParameter("USER_ID", userId);
		List<Users> userSearch= query.getResultList();
		return userSearch;
	}

	@Override
	public void updateHotel(Hotels hotel) 
	{
		Query query = entityManager.createQuery("Update Hotels SET city=:CITY, hotelName=:HOTEL_NAME, address=:ADDRESS, description=:DESCRIPTION, avgRatePerNight=:AVG_RATE_PER_NIGHT, phoneOne=:PHONE_NO1, phoneTwo=:PHONE_NO2, rating=:RATING, email=:EMAIL, fax=:FAX   where hotelId =:HOTEL_ID");
		
		query.setParameter("HOTEL_ID", hotel.getHotelId());
		query.setParameter("CITY", hotel.getCity());
		query.setParameter("HOTEL_NAME", hotel.getHotelName());
		query.setParameter("ADDRESS", hotel.getAddress());
		query.setParameter("DESCRIPTION", hotel.getDescription());
		query.setParameter("AVG_RATE_PER_NIGHT", hotel.getAvgRatePerNight());
		query.setParameter("PHONE_NO1", hotel.getPhoneOne());
		query.setParameter("PHONE_NO2", hotel.getPhoneTwo());
		query.setParameter("RATING", hotel.getRating());
		query.setParameter("EMAIL", hotel.getEmail());
		query.setParameter("FAX", hotel.getFax());
		query.executeUpdate();
	}

	@Override
	public List<Hotels> searchHotelsId(int id) 
	{
		Query query=entityManager.createQuery("FROM Hotels WHERE hotelId=:hotel_ID");
		query.setParameter("HOTEL_ID", id);
		List<Hotels> hotelSearch= query.getResultList();
		return hotelSearch;
	}

	@Override
	public List<RoomDetails> searchRoomsId(int id) 
	{
		Query query=entityManager.createQuery("FROM RoomDetails WHERE roomId=:room_ID");
		query.setParameter("ROOM_ID", id);
		List<RoomDetails> roomSearch= query.getResultList();
		return roomSearch;
	}
	
	

}
