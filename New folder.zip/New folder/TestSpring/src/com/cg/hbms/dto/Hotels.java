package com.cg.hbms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="HOTEL_HBMS")
public class Hotels
{
	@Id
	@Column(name="HOTEL_ID")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="hotelid")
	@SequenceGenerator(name="hotelid", sequenceName="HOTEL_HBMS_SEQ")
	private int hotelId;
	
	@Column(name="CITY")
	private String city;
	
	@Column(name="HOTEL_NAME")
	private String hotelName;
	
	@Column(name="ADDRESS")
	private String address;
	
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="AVG_RATE_PER_NIGHT")
	private Double avgRatePerNight;
	
	@Column(name="PHONE_NO1")
	private String phoneOne;
	
	@Column(name="PHONE_NO2")
	private String phoneTwo;
	
	@Column(name="RATING")
	private String rating;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="FAX")
	private String fax;

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getAvgRatePerNight() {
		return avgRatePerNight;
	}

	public void setAvgRatePerNight(Double avgRatePerNight) {
		this.avgRatePerNight = avgRatePerNight;
	}

	public String getPhoneOne() {
		return phoneOne;
	}

	public void setPhoneOne(String phoneOne) {
		this.phoneOne = phoneOne;
	}

	public String getPhoneTwo() {
		return phoneTwo;
	}

	public void setPhoneTwo(String phoneTwo) {
		this.phoneTwo = phoneTwo;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Override
	public String toString() {
		return "Hotels [hotelId=" + hotelId + ", city=" + city + ", hotelName="
				+ hotelName + ", address=" + address + ", description="
				+ description + ", avgRatePerNight=" + avgRatePerNight
				+ ", phoneOne=" + phoneOne + ", phoneTwo=" + phoneTwo
				+ ", rating=" + rating + ", email=" + email + ", fax=" + fax
				+ "]";
	}
	
}
