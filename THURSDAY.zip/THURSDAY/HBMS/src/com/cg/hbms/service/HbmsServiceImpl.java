package com.cg.hbms.service;

import java.util.List;

import com.cg.hbms.beans.BookingDetails;
import com.cg.hbms.beans.Hotels;
import com.cg.hbms.beans.RoomDetails;
import com.cg.hbms.beans.Users;
import com.cg.hbms.dao.HbmsDaoImpl;
import com.cg.hbms.dao.IHbmsDao;
import com.cg.hbms.exception.HbmsException;

public class HbmsServiceImpl implements IHbmsService 
{

	IHbmsDao daoObj = null;	
	
	@Override
	public int addUSer(Users user) throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		
		return daoObj.addUSer(user);
	}

	@Override
	public List<Users> showAll() throws HbmsException 
	{
		System.out.println("in service");
		daoObj = new HbmsDaoImpl();
		return daoObj.showAll();
	}

	@Override
	public int addHotel(Hotels hotel) throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		return daoObj.addHotel(hotel);
	}

	@Override
	public List<Hotels> showAllHotels() throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		return daoObj.showAllHotels();
	}

	@Override
	public int addRoomDetails(RoomDetails room) throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		return daoObj.addRoomDetails(room);
	}

	@Override
	public List<RoomDetails> showAllRooms() throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		return daoObj.showAllRooms();
	}

	@Override
	public int addBookingDetails(BookingDetails book) throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		return daoObj.addBookingDetails(book);
	}

	@Override
	public List<BookingDetails> showAllBookings() throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		return daoObj.showAllBookings();
	}

	@Override
	public List<Hotels> searchHotels(String city) throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		return daoObj.searchHotels(city);
	}

	@Override
	public List<RoomDetails> searchRooms(String type) throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		return daoObj.searchRooms(type);
	}

	@Override
	public void deleteHotel(int hotelId) throws HbmsException {
		daoObj = new HbmsDaoImpl();
		daoObj.deleteHotel(hotelId);
	}

	

	@Override
	public void deleteRoom(int roomId) throws HbmsException {
		daoObj = new HbmsDaoImpl();
		daoObj.deleteRoom(roomId);
		
	}

	@Override
	public void update(Hotels h) throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		daoObj.update(h);
	}

	@Override
	public Hotels search(int hotelId) throws HbmsException 
	{
		daoObj = new HbmsDaoImpl();
		return daoObj.search(hotelId);
	}


}
