package com.cg.hbms.exception;

public class HbmsException extends Exception 
{
	public HbmsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HbmsException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public HbmsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public HbmsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public HbmsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
