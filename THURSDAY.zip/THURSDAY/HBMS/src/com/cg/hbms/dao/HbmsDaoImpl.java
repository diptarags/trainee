package com.cg.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import javax.naming.NamingException;


import com.cg.hbms.beans.BookingDetails;
import com.cg.hbms.beans.Hotels;
import com.cg.hbms.beans.RoomDetails;
import com.cg.hbms.beans.Users;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.util.DbUtil;

public class HbmsDaoImpl implements IHbmsDao 
{

	Connection con=null;
	PreparedStatement pstm=null;
	
	private static final String QUERYVU = "SELECT * FROM USER_HBMS";
	private static final String QUERYVH = "SELECT * FROM HOTEL_HBMS";
	private static final String QUERYVR = "SELECT * FROM ROOM_HBMS";
	private static final String QUERYVB = "SELECT * FROM BOOKING_HBMS";
	private static final String UPDATE_QUERY = "UPDATE  HOTEL_HBMS SET    CITY = ? , HOTEL_NAME = ? , ADDRESS = ? , DESCRIPTION= ?, AVG_RATE_PER_NIGHT = ?, PHONE_NO1 = ?, PHONE_NO2=?, RATING=?, EMAIL=?, FAX=?  WHERE  HOTEL_ID = ?";
	private static final String SELECT_QUERY="SELECT * FROM hotel_hbms WHERE  HOTEL_ID = ?";
	
	@Override
	public int addUSer(Users user) throws HbmsException
	{
		int uId  = 0;
		
		try 
		{
			con = DbUtil.getConnection();
			String query = "INSERT INTO USER_HBMS Values(USER_HBMS_SEQ.NEXTVAL,?,?,?,?,?,?,?)";
			pstm = con.prepareStatement(query);
			
			pstm.setString(1, user.getPassword());
			pstm.setString(2, user.getRole());
			pstm.setString(3, user.getUserName());
			pstm.setString(4, user.getMobileNumber());
			pstm.setString(5, user.getPhoneNumber());
			pstm.setString(6, user.getAddress());
			pstm.setString(7, user.getEmail());
			
			pstm.executeUpdate();	
			
			PreparedStatement pstm1 = con.prepareStatement("SELECT USER_HBMS_SEQ.CURRVAL FROM DUAL");
			ResultSet rs = pstm1.executeQuery();

			while(rs.next())
			{
				uId = rs.getInt(1);
			}

		} 	
		catch (NamingException | SQLException e) 
		{
			//e.printStackTrace();
			throw new HbmsException("Error Occured while adding user's data");
		}
		
		
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e) 
			{
				//e.printStackTrace();
			}
		}
		return uId;
	}
	
	@Override
	public List<Users> showAll() throws HbmsException {
		System.out.println("in dao");
		List<Users> mylist = new LinkedList<Users>();
		try {
			con = DbUtil.getConnection();
			pstm = con.prepareStatement(QUERYVU);

			ResultSet result = pstm.executeQuery();

			while(result.next())
			{
				Users user = new Users();

				user.setUserId(result.getInt(1));
				user.setPassword(result.getString(2));
				user.setRole(result.getString(3));
				user.setUserName(result.getString(4));
				user.setMobileNumber(result.getString(5));
				user.setPhoneNumber(result.getString(6));
				user.setAddress(result.getString(7));
				user.setEmail(result.getString(8));
				
				mylist.add(user);
			}
		} 

		catch (NamingException | SQLException e) {
			throw new HbmsException(e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mylist;

	}
	
	@Override
	public int addHotel(Hotels hotel) throws HbmsException 
	{
		int hId = 0;
		
		try 
		{
			con = DbUtil.getConnection();
			String query = "INSERT INTO HOTEL_HBMS Values(HOTEL_HBMS_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";
			pstm = con.prepareStatement(query);
			
			pstm.setString(1, hotel.getCity());
			pstm.setString(2, hotel.getHotelName());
			pstm.setString(3, hotel.getAddress());
			pstm.setString(4, hotel.getDescription());
			pstm.setDouble(5, hotel.getNightRate());
			pstm.setString(6, hotel.getPhoneOne());
			pstm.setString(7, hotel.getPhoneTwo());
			pstm.setString(8, hotel.getRating());
			pstm.setString(9, hotel.getEmail());
			pstm.setString(10, hotel.getFax());
			
			pstm.executeUpdate();	
			System.out.println("DAO");
			PreparedStatement pstm1 = con.prepareStatement("SELECT HOTEL_HBMS_SEQ.CURRVAL FROM DUAL");
			ResultSet rs = pstm1.executeQuery();

			while(rs.next())
			{
				hId = rs.getInt(1);
			}
			System.out.println("DAO1");
		} 	
		catch (NamingException | SQLException e) 
		{
			//e.printStackTrace();
			throw new HbmsException("Error Occured while adding hotel's data");
		}
		
		
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e) 
			{
				//e.printStackTrace();
			}
		}
		return hId;
	}
	
	@Override
	public List<Hotels> showAllHotels() throws HbmsException 
	{
		List<Hotels> mylist = new LinkedList<Hotels>();
		try {
			con = DbUtil.getConnection();
			pstm = con.prepareStatement(QUERYVH);

			ResultSet result = pstm.executeQuery();

			while(result.next())
			{
				Hotels hotel = new Hotels();

				hotel.setHotelId(result.getInt(1));
				hotel.setCity(result.getString(2));
				hotel.setHotelName(result.getString(3));
				hotel.setAddress(result.getString(4));
				hotel.setDescription(result.getString(5));
				hotel.setNightRate(result.getDouble(6));
				hotel.setPhoneOne(result.getString(7));
				hotel.setPhoneTwo(result.getString(8));
				hotel.setRating(result.getString(9));
				hotel.setEmail(result.getString(10));
				hotel.setFax(result.getString(11));
				
				mylist.add(hotel);
			}
		} 

		catch (NamingException | SQLException e) {
			throw new HbmsException(e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mylist;
	}
	
	@Override
	public int addRoomDetails(RoomDetails room) throws HbmsException 
	{
		int rId = 0;
		
		try 
		{
			con = DbUtil.getConnection();
			String query = "INSERT INTO ROOM_HBMS Values(?,ROOM_HBMS_SEQ.NEXTVAL,?,?,?,?)";
			pstm = con.prepareStatement(query);
			
			pstm.setInt(1, room.getHotelId());
			pstm.setString(2, room.getRoomNo());
			pstm.setString(3, room.getRoomType());
			pstm.setString(4, room.getPerNightRate());
			pstm.setBoolean(5, room.getAvailability());
			
			pstm.executeUpdate();	
			
			PreparedStatement pstm1 = con.prepareStatement("SELECT ROOM_HBMS_SEQ.CURRVAL FROM DUAL");
			ResultSet rs = pstm1.executeQuery();

			while(rs.next())
			{
				rId = rs.getInt(1);
			}

		} 	
		catch (NamingException | SQLException e) 
		{
			//e.printStackTrace();
			throw new HbmsException("Error Occured while adding hotel's data");
		}
		
		
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e) 
			{
				//e.printStackTrace();
			}
		}
		return rId;
	}
	
	@Override
	public List<RoomDetails> showAllRooms() throws HbmsException 
	{
		List<RoomDetails> mylist = new LinkedList<RoomDetails>();
		try {
			con = DbUtil.getConnection();
			pstm = con.prepareStatement(QUERYVR);

			ResultSet result = pstm.executeQuery();

			while(result.next())
			{
				RoomDetails room = new RoomDetails();

				room.setHotelId(result.getInt(1));
				room.setRoomId(result.getInt(2));
				room.setRoomNo(result.getString(3));
				room.setRoomType(result.getString(4));
				room.setPerNightRate(result.getString(5));
				room.setAvailability(result.getBoolean(6));
				
				mylist.add(room);
			}
		} 

		catch (NamingException | SQLException e) {
			throw new HbmsException(e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mylist;
	}
	
	@Override
	public int addBookingDetails(BookingDetails book) throws HbmsException 
	{
		
		int bId = 0;
		
		try 
		{
			con = DbUtil.getConnection();
			String query = "INSERT INTO BOOKING_HBMS Values(BOOKING_HBMS_SEQ.NEXTVAL,?,?,?,?,?,?,?)";
			pstm = con.prepareStatement(query);
			
			pstm.setInt(1, book.getRoomId());
			pstm.setInt(2, book.getUserId());
			pstm.setDate(3, book.getBookedFrom());
			pstm.setDate(4, book.getBookedTo());
			pstm.setInt(5, book.getNoOfAdults());
			pstm.setInt(6, book.getNoOfChildren());
			pstm.setInt(7, book.getAmount());
			
			pstm.executeUpdate();	
			
			PreparedStatement pstm1 = con.prepareStatement("SELECT BOOKING_HBMS_SEQ.CURRVAL FROM DUAL");
			ResultSet rs = pstm1.executeQuery();

			while(rs.next())
			{
				bId = rs.getInt(1);
			}

		} 	
		catch (NamingException | SQLException e) 
		{
			//e.printStackTrace();
			throw new HbmsException("Error Occured while adding booking info");
		}
		
		
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e) 
			{
				//e.printStackTrace();
			}
		}
		return bId;
	}
	@Override
	public List<BookingDetails> showAllBookings() throws HbmsException 
	{
		System.out.println("In dao");
		
		List<BookingDetails> mylist = new LinkedList<BookingDetails>();
		try {
			con = DbUtil.getConnection();
			pstm = con.prepareStatement(QUERYVB);

			ResultSet result = pstm.executeQuery();

			while(result.next())
			{
				BookingDetails book = new BookingDetails();

				book.setBookingId(result.getInt(1));
				book.setRoomId(result.getInt(2));
				book.setUserId(result.getInt(3));
				book.setBookedFrom(result.getDate(4));
				book.setBookedTo(result.getDate(5));
				book.setNoOfAdults(result.getInt(6));
				book.setNoOfChildren(result.getInt(7));
				book.setAmount(result.getInt(8));
				
				mylist.add(book);
			}
		} 

		catch (NamingException | SQLException e) {
			throw new HbmsException(e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mylist;
	}

	@Override
	public List<Hotels> searchHotels(String city) throws HbmsException 
	{
	
		List<Hotels> mylist = new LinkedList<Hotels>();
		try 
		{
	
			
			con = DbUtil.getConnection();
			String querySh = "SELECT * FROM HOTEL_HBMS WHERE CITY=?";
			pstm = con.prepareStatement(querySh);
			pstm.setString(1, city);
			ResultSet result = pstm.executeQuery();

		
			while(result.next())
			{
				Hotels hotel = new Hotels();
			
				hotel.setHotelId(result.getInt(1));
				hotel.setCity(result.getString(2));
				hotel.setHotelName(result.getString(3));
				hotel.setAddress(result.getString(4));
				hotel.setDescription(result.getString(5));
				hotel.setNightRate(result.getDouble(6));
				hotel.setPhoneOne(result.getString(7));
				hotel.setPhoneTwo(result.getString(8));
				hotel.setRating(result.getString(9));
				hotel.setEmail(result.getString(10));
				hotel.setFax(result.getString(11));
				
				mylist.add(hotel);
	
			}
		} 

		catch (NamingException | SQLException e) {
			throw new HbmsException(e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mylist;
	}

	@Override
	public List<RoomDetails> searchRooms(String type) throws HbmsException 
	{

		List<RoomDetails> mylist = new LinkedList<RoomDetails>();
		try 
		{
	
			
			con = DbUtil.getConnection();
			String queryr = "SELECT * FROM ROOM_HBMS WHERE ROOM_TYPE=?";
			pstm = con.prepareStatement(queryr);
			pstm.setString(1, type);
			ResultSet result = pstm.executeQuery();

		
			while(result.next())
			{
				RoomDetails room = new RoomDetails();
			
				room.setHotelId(result.getInt(1));
				room.setRoomId(result.getInt(2));
				room.setRoomNo(result.getString(3));
				room.setRoomType(result.getString(4));
				room.setPerNightRate(result.getString(5));
				room.setAvailability(result.getBoolean(6));
				
				mylist.add(room);
	
			}
		} 

		catch (NamingException | SQLException e) {
			throw new HbmsException(e.getMessage());
		}
		finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mylist;
	}

	@Override
	public void deleteHotel(int hotelId) throws HbmsException {
		
		try {
			con = DbUtil.getConnection();
			String queryd = "DELETE FROM hotel_hbms WHERE hotel_id=?";
			pstm= con.prepareStatement(queryd);
			pstm.setInt(1, hotelId);
			ResultSet rs = pstm.executeQuery();
		} 
		
		catch (NamingException|SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new HbmsException("Hotel cannot be deleted..");
		} 
		
	}

	
	@Override
	public void deleteRoom(int roomId) throws HbmsException {
		try {
			con = DbUtil.getConnection();
			String queryd = "DELETE FROM room_hbms WHERE room_id=?";
			pstm= con.prepareStatement(queryd);
			pstm.setInt(1, roomId);
			ResultSet rs = pstm.executeQuery();
		} 
		
		catch (NamingException|SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new HbmsException("Room cannot be deleted..");
		} 
		
	}

	@Override
	public void update(Hotels h) throws HbmsException 
	{
try {
			
			con=DbUtil.getConnection();
			 pstm = con.prepareStatement(UPDATE_QUERY);
			 pstm.setInt(11, h.getHotelId());
			 pstm.setString(1, h.getCity());
			 pstm.setString(2, h.getHotelName());
			 pstm.setString(3, h.getAddress());
			 pstm.setString(4, h.getDescription());
			 pstm.setDouble(5, h.getNightRate());
			 pstm.setString(6, h.getPhoneOne());
			 pstm.setString(7, h.getPhoneTwo());
			 pstm.setString(8, h.getRating());
			 pstm.setString(9, h.getEmail());
			 pstm.setString(10, h.getFax());
			 
			 
			 System.out.println("before update");
			 pstm.executeUpdate();
			 System.out.println("after update");
			 System.out.println(h);	
			 con.close();
			 
		} 
	catch (NamingException  | SQLException e1) {
			
			e1.printStackTrace();
			throw new HbmsException("Unable to save, "+e1.getMessage());
		} 
	}

	@Override
	public Hotels search(int hotelId) throws HbmsException 
	{	
		System.out.println("in search");
		try {
			con = DbUtil.getConnection();
			String queryS = "SELECT * FROM hotel_hbms WHERE HOTEL_ID=?";
			pstm = con.prepareStatement(queryS);
			
			pstm.setInt(1, hotelId);
			
			ResultSet rs = pstm.executeQuery();
			Hotels h = new Hotels();
			if(rs.next()){
			
				h.setHotelId(rs.getInt(1));
				h.setCity(rs.getString(2));
				h.setHotelName(rs.getString(3));
				h.setAddress(rs.getString(4));
				h.setDescription(rs.getString(5));
				h.setNightRate(rs.getDouble(6));
				h.setPhoneOne(rs.getString(7));
				h.setPhoneTwo(rs.getString(8));
				h.setRating(rs.getString(9));
				h.setEmail(rs.getString(10));
				h.setFax(rs.getString(11));
				
				System.out.println("aftr search");
			}
			con.close();
			return h; 	
			
		} 
		catch (NamingException |SQLException e) 
		{
			e.printStackTrace();
			throw new HbmsException("Unable to fetch records, "+e.getMessage());
		}
	}

}
