function advalidate()
{
	var adusername = frm2.adusername.value;
	var adpassword = frm2.adpassword.value;
	
	if( adusername == "vinkle" && adpassword == "vinkle" )
		{
			frm2.action="adminhome.jsp";
		}
	else if( adusername == "sachin" && adpassword == "sachin" )
		{
			frm2.action="adminhome.jsp";
		}
	else if( adusername == "dipto" && adpassword == "dipto" )
		{
			frm2.action="adminhome.jsp";
		}
	else if( adusername == "paridhi" && adpassword == "paridhi" )
		{
			frm2.action="adminhome.jsp";	
		}
	else if( adusername == "shashank" && adpassword == "shashank" )
	{
		frm2.action="adminhome.jsp";	
	}
	else if( adusername == "sanchita" && adpassword == "sanchita" )
	{
		frm2.action="adminhome.jsp";	
	}
	else if( adusername == "sayontani" && adpassword == "sayontani" )
	{
		frm2.action="adminhome.jsp";	
	}
	else
		{
		 alert("Not a Valid ADMIN!");
		}
}