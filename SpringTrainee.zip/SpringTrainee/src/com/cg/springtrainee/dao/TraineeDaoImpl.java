package com.cg.springtrainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springtrainee.dto.Trainee;

@Repository("dao")
public class TraineeDaoImpl implements ITraineeDao{
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public void insertData(Trainee trainee) {
		
		entityManager.persist(trainee);
		entityManager.flush();
		
	}

	@Override
	public List<Trainee> showTrainee() {
		Query qureyOne = entityManager.createQuery("FROM Trainee");
		List<Trainee> allData = qureyOne.getResultList();
		
		return allData;
	}

	@Override
	public List<Trainee> searchData(int traineeId) {
		
		Query querytwo = entityManager.createQuery("FROM Trainee WHERE traineeId=:trainee_id");
		querytwo.setParameter("trainee_id", traineeId);
		List<Trainee> searchTrainee = querytwo.getResultList();
		
		return searchTrainee;
	}

	@Override
	public List<Trainee> removeData(int traineeId) {
		
		Query querytwo = entityManager.createQuery("FROM Trainee WHERE traineeId=:trainee_id");
		querytwo.setParameter("trainee_id", traineeId);
		List<Trainee> removeTrainee = querytwo.getResultList();
		
		Query queryThree = entityManager.createQuery("DELETE FROM Trainee WHERE traineeId=:trainee_id");
		queryThree.setParameter("trainee_id", traineeId);
		queryThree.executeUpdate();
		return removeTrainee;
	}

	@Override
	public void updateData(Trainee trainee) {
		Query queryFour = entityManager.createQuery("Update Trainee SET traineeName=:trainee_name ,traineeDomain=:trainee_domain, traineeLocation=:trainee_location  where traineeId =:trainee_id");
		queryFour.setParameter("trainee_id", trainee.getTraineeId());
		queryFour.setParameter("trainee_name", trainee.getTraineeName());
		queryFour.setParameter("trainee_domain", trainee.getTraineeDomain());
		queryFour.setParameter("trainee_location", trainee.getTraineeLocation());
		queryFour.executeUpdate();
	}
	
	

}
