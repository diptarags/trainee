package com.cg.springtrainee.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.cg.springtrainee.dto.Trainee;
import com.cg.springtrainee.service.ITraineeService;

@Controller
public class TraineeController {

	@Autowired
	ITraineeService service;
	
	//directing to add trainee jsp
	@RequestMapping(value="add" , method=RequestMethod.GET)
	public String addData(@ModelAttribute("my") Trainee tran, Map<String,Object> model)
	{
		List<String> domainList= new ArrayList<String>();
		
		domainList.add("Java");
		domainList.add("Testing");
		domainList.add("Mainframe");
		domainList.add(".NET");
		
		model.put("tType", domainList);
		
		return "addTrainee";
		
	}
	
	//add
	@RequestMapping(value="putData", method=RequestMethod.POST)
	public String dataAdd(@ModelAttribute("my") Trainee tran)
	{
		service.insertData(tran);
		return "redirect:/login.jsp";
		
	}
	
	//show all
	@RequestMapping(value="showAll", method=RequestMethod.GET)
	public ModelAndView showData()
	{
		List<Trainee> dataList=service.showTrainee();
		
		return new ModelAndView("show", "trainee", dataList);
		
	}
	
	//directed to search jsp
	@RequestMapping(value="search", method=RequestMethod.GET)
	public String searchPage(@ModelAttribute("mysearch") Trainee tran)
	{
		return "search";
		
	}
	
	//search
	@RequestMapping(value="searchdata", method=RequestMethod.POST)
	public ModelAndView searchData(@ModelAttribute("mysearch") Trainee tran)
	{
		int tranId = tran.getTraineeId();
		List<Trainee> mySearch = service.searchData(tranId);
		
		return new ModelAndView("show", "trainee", mySearch);
		
	}
	
	//directed to delete
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public String traineeRemove(@ModelAttribute("mysearch") Trainee tran)
	{
		return "traineeRemove";
		
	}
	
	//delete
	@RequestMapping(value="removedata", method=RequestMethod.POST)
	public ModelAndView removeData(@ModelAttribute("mysearch") Trainee tran)
	{
		int tranId = tran.getTraineeId();
		List<Trainee> deleteData=service.removeData(tranId);
		
		return new ModelAndView("show", "trainee", deleteData);
		
	}
	
	// directed to update jsp
	@RequestMapping(value="update", method=RequestMethod.GET)
	public String updateTrainee(@ModelAttribute("mysearch") Trainee tran)
	{
		return "UpdateTrainee";
		
	}
	
	//searching trainee
	@RequestMapping(value="searchtrainee", method=RequestMethod.POST)
	public ModelAndView searchTrainee(@ModelAttribute("mysearch") Trainee tran, Map<String,Object> model)
	{

		List<String> domainList= new ArrayList<String>();
		
		domainList.add("Java");
		domainList.add("Testing");
		domainList.add("Mainframe");
		domainList.add(".NET");
		
		model.put("tType", domainList);
		
		int tranId = tran.getTraineeId();
		List<Trainee> mySearch = service.searchData(tranId);
		
		return new ModelAndView("Update", "trainee", mySearch);
		
	}
	
	//update
	@RequestMapping(value ="putdata" , method = RequestMethod.POST)
	public String updateData(@ModelAttribute("mysearch")Trainee tran)
	{
		service.updateData(tran);
		
		return "redirect:/login.jsp";
		
	}
	
	
	
}
