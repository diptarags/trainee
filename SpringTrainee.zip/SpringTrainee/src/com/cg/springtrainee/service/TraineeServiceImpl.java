package com.cg.springtrainee.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springtrainee.dao.ITraineeDao;
import com.cg.springtrainee.dto.Trainee;

@Service("service")
@Transactional
public class TraineeServiceImpl implements ITraineeService{

	@Autowired
	ITraineeDao dao;
	
	@Override
	public void insertData(Trainee trainee) 
	{
		dao.insertData(trainee);
		
	}

	@Override
	public List<Trainee> showTrainee() {
		
		return dao.showTrainee();
	}

	@Override
	public List<Trainee> searchData(int traineeId) {
		
		return dao.searchData(traineeId);
	}

	@Override
	public List<Trainee> removeData(int traineeId) {
		
		return dao.removeData(traineeId);
		
	}

	@Override
	public void updateData(Trainee trainee) {
		dao.updateData(trainee);
		
	}

}
