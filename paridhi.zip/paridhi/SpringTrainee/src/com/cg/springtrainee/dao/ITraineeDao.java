package com.cg.springtrainee.dao;

import java.util.List;

import com.cg.springtrainee.dto.Trainee;

public interface ITraineeDao {

	public int insertData(Trainee trainee);
	
	public List<Trainee> showTrainee();
	
	public List<Trainee> searchData(int traineeId);
	
	public List<Trainee> removeData(int traineeId);
	
	public void updateData(Trainee trainee);
	
}
