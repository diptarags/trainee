package com.capgemini.traineemanagementsystem.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.traineemanagementsystem.bean.TraineeBean;
import com.capgemini.traineemanagementsystem.dao.ITraineeDAO;

@Service("traineeservice")
@Transactional
public class TraineeService implements ITraineeService
{
	@Autowired
	ITraineeDAO traineedao;
	
	@Override
	public int addTrainee(TraineeBean trainee) 
	{
		return traineedao.addTrainee(trainee);
	}

	@Override
	public void deleteTrainee(int traineeId) 
	{
		traineedao.deleteTrainee(traineeId);
	}

	@Override
	public void updateTrainee(TraineeBean trainee) 
	{
		traineedao.updateTrainee(trainee);
	}

	@Override
	public List<TraineeBean> searchTrainee(int traineeId) 
	{
		return traineedao.searchTrainee(traineeId);
	}

	@Override
	public List<TraineeBean> showTrainee() 
	{
		return traineedao.showTrainee();
	}
}