package com.capgemini.traineemanagementsystem.service;

import java.util.List;

import com.capgemini.traineemanagementsystem.bean.TraineeBean;

public interface ITraineeService 
{
	public int addTrainee(TraineeBean trainee);

	public void deleteTrainee(int traineeId);
	
	public void updateTrainee(TraineeBean trainee);
	
    public List<TraineeBean> searchTrainee(int traineeId);
    
    public List<TraineeBean> showTrainee();
}