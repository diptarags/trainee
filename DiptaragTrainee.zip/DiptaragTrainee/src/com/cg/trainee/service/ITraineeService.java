package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.beans.Trainee;


public interface ITraineeService 
{
	public void insertData(Trainee trainee);
	
	public List<Trainee> showTrainee();
	
	public List<Trainee> searchData(int traineeId);
	
	public List<Trainee> removeData(int traineeId);
	
	public void updateData(Trainee trainee);

}
