package com.cg.trainee.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.trainee.beans.Trainee;
import com.cg.trainee.service.ITraineeService;

@Controller
public class TraineeController 
{
	@Autowired
	ITraineeService service;
	
	@RequestMapping(value="add" , method=RequestMethod.GET)
	public String addData(@ModelAttribute("dipta") Trainee tran, Map<String,Object> model)
	{
		List<String> domainList= new ArrayList<String>();
		
		domainList.add("Java");
		domainList.add("Testing");
		domainList.add("Mainframe");
		domainList.add(".NET");
		
		model.put("tType", domainList);
		
		return "addTrainee";

}
	
	
	@RequestMapping(value="putdata" , method=RequestMethod.POST)
	public String dataAdd(@ModelAttribute("dipta") Trainee tran)
	{
		service.insertData(tran);
		return "login";
		
	}
	
	@RequestMapping(value="showall", method=RequestMethod.GET)
	public ModelAndView showData()
	{
		List<Trainee> dataList = service.showTrainee();
		return new ModelAndView("Show", "trainee", dataList);
		
	}
	
	
	
	//directed to delete
		@RequestMapping(value="remove", method=RequestMethod.GET)
		public String traineeRemove(@ModelAttribute("mysearch") Trainee tran)
		{
			return "traineeRemove";
			
		}
		
		//delete
		@RequestMapping(value="removedata", method=RequestMethod.POST)
		public ModelAndView removeData(@ModelAttribute("mysearch") Trainee tran)
		{
			int tranId = tran.getID();
			List<Trainee> deleteData=service.removeData(tranId);
			
			return new ModelAndView("show", "trainee", deleteData);
			
		}
}
