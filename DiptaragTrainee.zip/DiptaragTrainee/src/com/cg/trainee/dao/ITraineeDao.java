package com.cg.trainee.dao;

import java.util.List;

import com.cg.trainee.beans.Trainee;

public interface ITraineeDao 
{
	public void insertData(Trainee trainee);
	
	public List<Trainee> showTrainee();
	
	public List<Trainee> searchData(int traineeId);
	
	public List<Trainee> removeData(int traineeId);
	
	public void updateData(Trainee trainee);

}
