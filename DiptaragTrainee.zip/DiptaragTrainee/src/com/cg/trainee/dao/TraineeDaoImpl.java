package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.trainee.beans.Trainee;

@Repository("dao")
public class TraineeDaoImpl implements ITraineeDao
{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public void insertData(Trainee trainee) {
		
		entityManager.persist(trainee);
		entityManager.flush();
		
	}

	@Override
	public List<Trainee> showTrainee() {
		
		Query queryOne = entityManager.createQuery("FROM Trainee");
		List<Trainee> showData = queryOne.getResultList();
		
		return showData;
	}

	@Override
	public List<Trainee> searchData(int traineeId) {
		
		return null;
	}

	@Override
	public List<Trainee> removeData(int traineeId) {
		
		Query querytwo = entityManager.createQuery("FROM Trainee WHERE ID=:id");
		querytwo.setParameter("id", traineeId);
		List<Trainee> removeTrainee = querytwo.getResultList();
		
		Query queryThree = entityManager.createQuery("DELETE FROM Trainee WHERE ID=:id");
		queryThree.setParameter("id", traineeId);
		queryThree.executeUpdate();
		return removeTrainee;
		
	}

	@Override
	public void updateData(Trainee trainee) {
		
		
	}
	

}
